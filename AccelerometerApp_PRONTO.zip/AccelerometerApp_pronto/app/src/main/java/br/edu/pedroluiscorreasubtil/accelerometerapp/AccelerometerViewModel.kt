package br.edu.pedroluiscorreasubtil.accelerometerapp

import android.app.Application
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.lifecycle.AndroidViewModel
import kotlinx.flow.MutableStateFlow
import kotlinx.flow.StateFlow
import kotlinx.flow.asStateFlow
import kotlinx.flow.update
import kotlin.math.sqrt

/**
 * ATIVIDADE PRÁTICA: Aplicativo de Leitura do Acelerômetro
 * ALUNO: Pedro Luis Correa Subtil
 * 
 * Descrição: ViewModel responsável por gerenciar a lógica de captura dos dados do sensor
 * acelerômetro do dispositivo, aplicando filtros matemáticos para separar a gravidade 
 * e a aceleração linear, mantendo o estado de UI protegido por fluxos reativos.
 */

data class AccelerometerUiState(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f,
    val linearAcceleration: Float = 0f,
    val gravity: Float = 0f
)

class AccelerometerViewModel(application: Application) : AndroidViewModel(application), SensorEventListener {

    private val sensorManager = application.getSystemService(Application.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    // Fluxo de estado interno mutável e externo imutável para atualização em tempo real
    private val _uiState = MutableStateFlow(AccelerometerUiState())
    val uiState: StateFlow<AccelerometerUiState> = _uiState.asStateFlow()

    // Constante alfa para o filtro passa-baixa (isolamento da aceleração gravitacional)
    private val alpha: Float = 0.8f
    private val gravityArray = FloatArray(3) { 0f }

    fun startListening() {
        // Registra o listener para atualizações contínuas do sensor em tempo real
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    fun stopListening() {
        // Desregistra o listener para economizar recursos de hardware quando o app estiver em background
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return

        // 1. FILTRO PASSA-BAIXA: Isolação da aceleração da gravidade por atenuação de picos rápidos
        gravityArray[0] = alpha * gravityArray[0] + (1 - alpha) * event.values[0]
        gravityArray[1] = alpha * gravityArray[1] + (1 - alpha) * event.values[1]
        gravityArray[2] = alpha * gravityArray[2] + (1 - alpha) * event.values[2]

        // Cálculo vetorial da magnitude total da aceleração da gravidade
        val totalGravity = sqrt(
            gravityArray[0] * gravityArray[0] +
            gravityArray[1] * gravityArray[1] +
            gravityArray[2] * gravityArray[2]
        )

        // 2. FILTRO PASSA-ALTA: Remoção do componente estático da gravidade para isolar a aceleração linear do usuário
        val linearX = event.values[0] - gravityArray[0]
        val linearY = event.values[1] - gravityArray[1]
        val linearZ = event.values[2] - gravityArray[2]

        // Cálculo vetorial da magnitude total da aceleração linear gerada pelo movimento físico
        val totalLinear = sqrt(linearX * linearX + linearY * linearY + linearZ * linearZ)

        // Atualização reativa do estado atômico da interface gráfica
        _uiState.update { currentState ->
            currentState.copy(
                x = event.values[0],
                y = event.values[1],
                z = event.values[2],
                linearAcceleration = totalLinear,
                gravity = totalGravity
            )
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onCleared() {
        super.onCleared()
        stopListening()
    }
}
